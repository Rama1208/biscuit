function checkMandatory()
{
 var fn=document.getElementById('txtFN').value;
 var sn=document.getElementById('txtSN').value;
 if(fn!="" && sn!="")
 return true;
 else if(fn!="" && sn==""){
 alert('Second number is mandatory');
  return false;
 }
 else if(sn!="" && fn==""){
 alert('First number is mandatory');
  return false;
 }
 else{
 alert('Both numbers are mandatory');
 return false;
 }
 }
function AddNum()
{
  alert("hi1");
  var fn=document.getElementById("txtFN").value;
  var sn=document.getElementById("txtSN").value;
  if(checkMandatory())
  {
  var result=parseInt(fn) +parseInt(sn);
  document.getElementById("txtResult").value=result;
  }
}
function ClearValues()
{
 document.getElementById("txtFN").value="";
 document.getElementById("txtSN").value="";
 document.getElementById("txtResult").value="";
}
function SubNum()
{
  alert("hi1");
  var fn=document.getElementById("txtFN").value;
  var sn=document.getElementById("txtSN").value;
  if(checkMandatory())
  {
  var result=parseInt(fn) - parseInt(sn);
  document.getElementById("txtResult").value=result;
  }
}
function MulNum()
{
  alert("hi1");
  var fn=document.getElementById("txtFN").value;
  var sn=document.getElementById("txtSN").value;
  if(checkMandatory())
  {
  var result=parseInt(fn) * parseInt(sn);
  document.getElementById("txtResult").value=result;
  }
}
function DivNum()
{
  alert("hi1");
  var fn=document.getElementById("txtFN").value;
  var sn=document.getElementById("txtSN").value;
  if(checkMandatory())
  {
  var result=parseInt(fn) / parseInt(sn);
  document.getElementById("txtResult").value=result;
  }
}
function PowNum()
{
  alert("hi1");
  var fn=document.getElementById("txtFN").value;
  var sn=document.getElementById("txtSN").value;
  if(checkMandatory())
  {
  var result=1;
  for(i=1;i<=sn;i++){
  
  result*=fn;
  }
  document.getElementById("txtResult").value=result;
  }
}