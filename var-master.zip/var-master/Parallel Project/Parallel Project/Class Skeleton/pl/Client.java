package com.cg.mypaymentapp.pl;

public class Client {
	   public static void main( String[] args ){
	        
	    }
}
